import React from 'react';
import ReactDOM from 'react-dom';
import {TopNav} from './topnav';
class Parent extends React.Component{
	render()
	{
		return(
			<div>
				<TopNav />
			</div>
		);
	}
}

ReactDOM.render(<Parent />, document.getElementById('root'));
