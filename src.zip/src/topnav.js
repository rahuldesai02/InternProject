import React from 'react';
import logo from './top-nav-logo.jpg';
import './top-nav.css'

export class TopNav extends React.Component {
  render() {
    return (
      <div>
        <nav>
          {/* <span class="logo"><img src = {logo}/></span>

          <ul class="menu-area">
            <li><span><h1 align = 'center'>TITLE</h1></span></li>
          <li><span><h1>USER LOGGED IN</h1></span></li>
          </ul> */}
          <div class="grid-container">
          <div class="grid-item"><img src = {logo}/></div>
        <div class="grid-item"><h2>TITLE</h2></div>
      <div class="grid-item">LOGGED IN USER</div>
        </div>
        </nav>
      </div>);
  }
}
